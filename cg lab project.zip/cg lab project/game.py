import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Set up the display
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Interactive Game")

# Define colors
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)
black = (0, 0, 0)

# Initial position and size of the player rectangle
player_x, player_y = 400, 300
player_width = 50
player_height = 50

# Create an item to collect
item_x = random.randint(0, 750)
item_y = random.randint(0, 550)
item_size = 30

# Score and game state
score = 0
font = pygame.font.Font(None, 36)
game_state = "start"  # Possible values: start, playing, win, lose

# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    # Start the game
    if game_state == "start":
        screen.fill(white)
        start_text = font.render("Press ENTER to Start", True, black)
        screen.blit(start_text, (250, 250))
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_RETURN]:  # Start the game
            game_state = "playing"

    # Playing the game
    elif game_state == "playing":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            player_x -= 5
        if keys[pygame.K_RIGHT]:
            player_x += 5
        if keys[pygame.K_UP]:
            player_y -= 5
        if keys[pygame.K_DOWN]:
            player_y += 5

        # Check for collision with the item
        if (item_x < player_x < item_x + item_size and
            item_y < player_y < item_y + item_size):
            score += 1
            item_x = random.randint(0, 750)
            item_y = random.randint(0, 550)
            player_width += 5

        # Check win condition (for example, score of 10)
        if score >= 10:
            game_state = "win"

        # Fill the screen with white
        screen.fill(white)
        pygame.draw.rect(screen, red, (player_x, player_y, player_width, player_height))
        pygame.draw.rect(screen, green, (item_x, item_y, item_size, item_size))

        # Render the score
        score_text = font.render(f'Score: {score}', True, black)
        screen.blit(score_text, (10, 10))

        # Check for quit
        if keys[pygame.K_q]:  # Press 'Q' to quit
            pygame.quit()
            sys.exit()

    # Win condition
    elif game_state == "win":
        screen.fill(white)
        win_text = font.render("You Win! Press R to Restart or Q to Quit", True, black)
        screen.blit(win_text, (150, 250))
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:  # Restart the game
            score = 0
            player_width = 50
            game_state = "start"
        if keys[pygame.K_q]:  # Quit the game
            pygame.quit()
            sys.exit()

    # Update the display
    pygame.display.flip()
    pygame.time.delay(30)